﻿create database Advising_Team_12;

	Go 
Create procedure CreateAllTables
	AS 
Create table Advisor(
		advisor_id int primary key identity,
		name varchar(40),
		email varchar(40),
		office varchar(40),
		password varchar(40));

	Create table Student(
		Student_id int primary key identity,
		f_name varchar(40),
		l_name varchar(40),
		gpa decimal,
		faculty varchar(40),
		email varchar(40),
		major varchar(40),
		password varchar(40),
		financial_status bit,
		semester int,
		acquired_hours int,
		assigned_hours int,
		advisor_id int,
		constraint FK_Student_advisor_id foreign key (advisor_id) references Advisor);
		
	Create table Student_Phone(
		Student_id int,
		Phone_number varchar(40),
		Constraint PK_Student_Phone primary key (Student_id, Phone_number),
		Constraint FK_SP_Student_id foreign key (Student_id) references Student);
		

	Create table Course(
		course_id int identity primary key,
		name varchar(40),
		major varchar(40),
		is_offered bit,
		credit_hours int,
		semester int);

	Create table PreqCourse_course(
		prerequisite_course_id int,
		course_id int
		Constraint PK_PreqCourse_course primary key (prerequisite_course_id, course_id),
		Constraint FK_prerequisite_course_id foreign key (prerequisite_course_id) references Course,
		Constraint FK_PreqCourse_course_id foreign key (course_id) references course 
		);

	create table Instructor(
		instructor_id int primary key identity,
		name varchar(40),
		email varchar(40),
		faculty varchar(40),
		office varchar(40));

	create table Instructor_Course(
		course_id int,
		instructor_id int,
		Constraint PK_Instructor_Course primary key (course_id, instructor_id),
		Constraint FK_IC_course_id foreign key (course_id) references Course,
		Constraint FK_IC_instructor_id foreign key (instructor_id) references Instructor);

	Create table Student_Instructor_Course_Take(
		student_id int,
		course_id int,
		instructor_id int,
		semester_code varchar(40),
		exam_type varchar(40) default 'Normal',
		grade varchar(40),
		Constraint PK_Student_Instructor_Course_Take primary key (student_id ,course_id, instructor_id),
		Constraint FK_SICT_course_id foreign key (course_id) references Course,
		Constraint FK_SICT_student_id foreign key (student_id) references Student,
		Constraint FK_SICT_instructor_id foreign key (instructor_id) references Instructor);

	Create table Semester(
		semester_code varchar(40) primary key,
		start_date date,
		end_date date);

	Create table Course_Semester(
		course_id int,
		semester_code varchar(40),
		Constraint PK_Course_Semester primary key (semester_code ,course_id),
		Constraint FK_CS_course_id foreign key (course_id) references Course,
		Constraint FK_CS_semester_code foreign key (semester_code) references Semester);

	

	Create table slot(
		slot_id int primary key identity, 
		day varchar(40),
		time varchar(40),
		location varchar(40),
		course_id int ,
		instructor_id int,
		Constraint FK_Slot_course_id foreign key (course_id) references Course,
		Constraint FK_Slot_instructor_id foreign key (instructor_id) references instructor);

	Create table Graduation_Plan(
		plan_id int identity,
		semester_code varchar(40),
		semester_credit_hours int, 
		expected_grad_date date,  
		advisor_id int, 
		student_id int,
		Constraint PK_Graduation_Plan primary key (plan_id, semester_code),
		Constraint FK_GP_advisor_id foreign key (advisor_id) references Advisor,
		Constraint FK_GP_student_id foreign key (student_id) references student);

	
	Create table GradPlan_Course (
		plan_id int, 
		semester_code varchar(40), 
		course_id int
		Constraint PK_GradPlan_Course primary key (plan_id, semester_code, course_id),
		Constraint FK_GPC_plan_id foreign key (plan_id,semester_code) references Graduation_Plan);
		

	Create table Request (
		request_id int identity primary key, 
		type varchar(40), 
		comment varchar(40),
		status varchar(40) default 'pending',
		credit_hours int , 
		student_id int, 
		advisor_id int,
		course_id int
		Constraint FK_Req_advisor_id foreign key (advisor_id) references Advisor,
		Constraint FK_Req_student_id foreign key (student_id) references student);
	
	Create table MakeUp_Exam (
		exam_id int identity primary key, 
		date date , 
		type varchar(40) default 'Normal', 
		course_id int,
		Constraint FK_ME_course_id foreign key (course_id) references Course);

	Create table Exam_Student (
		exam_id int, 
		student_id int, 
		course_id int
		Constraint PK_Exam_Student primary key (exam_id ,student_id),
		Constraint FK_ES_exam_id foreign key (exam_id) references MakeUp_Exam,
		Constraint FK_ES_student_id foreign key (student_id) references Student);
		
	Create table Payment(
		payment_id int identity primary key,
		amount int,
		deadline datetime,
		n_installments int default 0,
		status varchar(40) default 'notPaid', 
		fund_percentage decimal(5,2),
		start_date datetime,
		student_id int, 
		semester_code varchar(40)
		Constraint FK_Payment_student_id foreign key (student_id) references Student,
		Constraint FK_Payment_semester_code foreign key (semester_code) references Semester);
		
	Create table Installment(
		payment_id int, 
		deadline datetime, 
		amount int, 
		status varchar(40) default 'notPaid', 
		start_date datetime,
		Constraint PK_Installment primary key (Payment_id ,deadline),
		Constraint FK_Installment_payment_id foreign key (payment_id) references Payment);
		
Go

execute CreateAllTables

Go
	Create procedure DropAllTables
	as
	drop table Instructor_Course
	drop table Student_Instructor_Course_Take
	drop table Student_Phone
	drop table PreqCourse_course
	drop table Course_Semester
	drop table GradPlan_Course
	drop table Exam_Student
	drop table Slot
	drop table Graduation_Plan
	drop table Request
	drop table MakeUp_Exam
	drop table Installment
	drop table Payment
	drop table Student
	drop table Course
	drop table Instructor
	drop table Semester 
	drop table Advisor

Go

	Create procedure clearAllTables
	as
	
	alter table Instructor_course
	drop constraint FK_IC_course_id, FK_IC_instructor_id;
	
	alter table Student_Instructor_Course_Take
	drop constraint FK_SICT_course_id, FK_SICT_student_id, FK_SICT_instructor_id;

	alter table PreqCourse_course
	drop constraint FK_prerequisite_course_id, FK_PreqCourse_course_id;

	alter table Student_Phone
	drop constraint FK_SP_Student_id;

	
	alter table Course_Semester
	drop constraint FK_CS_course_id, FK_CS_semester_code;

	
	alter table GradPlan_Course
	drop constraint FK_GPC_plan_id;

	
	alter table Exam_Student
	drop constraint FK_ES_exam_id, FK_ES_student_id;

	
	alter table Slot
	drop constraint FK_Slot_course_id, FK_Slot_instructor_id;


	alter table Graduation_Plan
	drop constraint FK_GP_advisor_id, FK_GP_student_id;

	alter table Request
	drop constraint FK_Req_advisor_id, FK_Req_student_id;

	alter table MakeUp_Exam
	drop constraint FK_ME_course_id;

	alter table Installment
	drop constraint FK_Installment_payment_id;

	alter table Payment
	drop constraint FK_Payment_student_id, FK_Payment_semester_code;

	alter table Student
	drop constraint FK_Student_advisor_id;

	Truncate table Instructor_Course
	Truncate table Student_Instructor_Course_Take
	Truncate table Student_Phone
	Truncate table PreqCourse_course
	Truncate table Course_Semester
	Truncate table GradPlan_Course
	Truncate table Exam_Student
	Truncate table Slot
	Truncate table Graduation_Plan
	Truncate table Request
	Truncate table MakeUp_Exam
	Truncate table Installment
	Truncate table Payment
	Truncate table Student
	Truncate table Course
	Truncate table Instructor
	Truncate table Semester 
	Truncate table Advisor


	alter table Instructor_course
	add Constraint FK_IC_course_id foreign key (course_id) references Course,
	Constraint FK_IC_instructor_id foreign key (instructor_id) references Instructor;
	
	alter table PreqCourse_course
	add Constraint FK_prerequisite_course_id foreign key (prerequisite_course_id) references Course,
		Constraint FK_PreqCourse_course_id foreign key (course_id) references course;

	alter table Student_Phone
	add Constraint FK_SP_Student_id foreign key (Student_id) references Student;

	
	alter table Course_Semester
	add Constraint FK_CS_course_id foreign key (course_id) references Course,
		Constraint FK_CS_semester_code foreign key (semester_code) references Semester;
	
	alter table GradPlan_Course
	add Constraint FK_GPC_plan_id foreign key (plan_id,semester_code) references Graduation_Plan;


	alter table Exam_Student
	add Constraint FK_ES_exam_id foreign key (exam_id) references MakeUp_Exam,
		Constraint FK_ES_student_id foreign key (student_id) references Student;

	alter table Student_Instructor_Course_Take
	add Constraint FK_SICT_course_id foreign key (course_id) references Course,
		Constraint FK_SICT_student_id foreign key (student_id) references Student,
		Constraint FK_SICT_instructor_id foreign key (instructor_id) references Instructor;

	
	alter table Slot
	add Constraint FK_Slot_course_id foreign key (course_id) references Course,
		Constraint FK_Slot_instructor_id foreign key (instructor_id) references instructor;


	alter table Graduation_Plan
	add Constraint FK_GP_advisor_id foreign key (advisor_id) references Advisor,
		Constraint FK_GP_student_id foreign key (student_id) references student;

	alter table Request
	add Constraint FK_Req_advisor_id foreign key (advisor_id) references Advisor,
		Constraint FK_Req_student_id foreign key (student_id) references student;

	alter table MakeUp_Exam
	add Constraint FK_ME_course_id foreign key (course_id) references Course;

	alter table Installment
	add Constraint FK_Installment_payment_id foreign key (payment_id) references Payment;

	alter table Payment
	add Constraint FK_Payment_student_id foreign key (student_id) references Student,
		Constraint FK_Payment_semester_code foreign key (semester_code) references Semester;

	alter table Student
	add constraint FK_Student_advisor_id foreign key (advisor_id) references Advisor;

	
Go

	create view view_Student
	AS 
	Select *
	from Student
	where Student_id is not null;

Go

	create view view_Course_prerequisites
	AS
	select pc.prerequisite_course_id, C.*
	from PreqCourse_course pc
		inner join Course c on c.course_id = pc.course_id

Go
	create view Instructors_AssignedCourses
	AS 
	select I.instructor_id, I.name AS Instructor_Name, I.email, I.faculty, I.office,  C.course_id, C.name AS Course_Name, C.credit_hours, C.is_offered, C.major, C.semester
	from Instructor I
	inner join Instructor_Course IC on IC.instructor_id=I.instructor_id
	inner join Course C on c.course_id=IC.course_id;
	
Go 
	Create view Student_Payment
	As
	select Student.*,P.payment_id, P.amount, P.deadline, P.fund_percentage, P.n_installments, P.semester_code, P.start_date, P.status
	from Payment P
	inner join Student on Student.Student_id=P.student_id

Go 
	Create view Courses_Slots_Instructor
	AS
	select  C.course_id, C.name As course_Name, S.slot_id, S.day, S.time, S.location, I.name As Instructor_Name
	from Slot S
	inner join Instructor I on I.instructor_id=s.instructor_id
	inner join Course C on C.course_id=s.course_id
Go 

	Create view Courses_MakeupExams
	AS
	select C.name AS Course_Name , C.semester, E.*
	From makeup_Exam E
	inner join Course C on C.course_id=E.course_id
Go 

	Create view Students_Courses_transcript
	AS 
	select S.Student_id, S.f_name, S.l_name, C.course_id, C.name AS Course_name, SICT.exam_type,
	SICT.grade, SICT.semester_code, I.name as Instructor_name
	From Student_Instructor_Course_Take SICT
	inner join Student S on S.Student_id=SICT.student_id 
	inner join Course C on C.course_id=SICT.course_id
	inner join Instructor I on I.instructor_id=SICT.instructor_id
Go 
	Create view Semster_offered_Courses
	AS
	select C.course_id, C.name, CS.semester_code
	From Course_Semester CS
	inner join Course C on C.course_id=CS.course_id
Go

	Create view Advisors_Graduation_Plan
	AS
	select GP.*, A.name As Advisor_name
	from Advisor A
	inner join Graduation_Plan GP on GP.advisor_id=A.advisor_id
Go


	Create procedure Procedures_StudentRegistration
		@f_name varchar (40), 
		@l_name varchar (40), 
		@password varchar (40), 
		@faculty varchar (40), 
		@email varchar (40), 
		@major varchar (40), 
		@Semester int,
		@Student_id int output
	As 
	insert into Student(f_name, l_name, password, faculty, email, major, 
	Semester)
	values(@f_name, @l_name, @password, @faculty, @email, @major, @Semester)

	select @Student_id=Student_id 
		from Student 
		where @f_name = f_name and 
		@l_name = l_name and 
		@password = password and  
		@faculty = faculty and 
		@email = email and
		@major = major and 
		@Semester = semester 

Go

	Create procedure Procedures_AdvisorRegistration
		@advisor_name varchar (40), 
		@password varchar (40), 
		@email varchar (40), 
		@office varchar (40),
		@Advisor_id int output

		As

		insert into Advisor(name, email, office, password)
		values(@advisor_name, @email, @office, @password)

		select @advisor_id=advisor_id
		from advisor
		where name = @advisor_name  and password = @password and
		email = @email and  office = @office 

Go

	Create Procedure Procedures_AdminListStudents
		As

		select f_name+ ' ' + l_name AS Student_Name 
		from student 
		where Advisor_id is not null

Go

	Create Procedure Procedures_AdminListAdvisors
		As

		select name
		from Advisor 

Go 

	Create Procedure AdminListStudentsWithAdvisors
		As

		select S.f_name+ ' ' + S.l_name AS Student_Name , A.name
		from Student S
		inner join Advisor A
		on A.advisor_id=S.advisor_id

Go 

	Create procedure AdminAddingSemester
		@start_date date, 
		@end_date date, 
		@semester_code varchar(40)
		As

		insert into Semester(semester_code, start_date, end_date)
		Values(@semester_code, @start_date, @end_date)

Go

	Create procedure Procedures_AdminAddingCourse
		@major varchar (40), 
		@semester int, 
		@credit_hours int, 
		@course_name varchar (40),
		@offered bit
		AS 

		insert into Course(name, major, is_offered, credit_hours, semester)
		values (@course_name, @major, @offered, @credit_hours, @semester)

Go

	Create procedure Procedures_AdminLinkInstructor
		@InstructorId int, 
		@courseId int, 
		@slotID int
		As

		update slot 
		set instructor_id= @instructorId, course_id= @courseId
		where slot_id=@slotID

Go

	Create procedure Procedures_AdminLinkStudent
		@Instructor_Id int, 
		@student_ID int, 
		@course_ID varchar(40), 
		@semester_code varchar (40)
		As

		insert into Student_Instructor_Course_Take (student_id, course_id, instructor_id, semester_code)
		values(@student_ID, @course_ID, @Instructor_Id, @semester_code)

Go

	Create procedure Procedures_AdminLinkStudentToAdvisor 
		 @studentID int, 
		 @advisorID int
		 As

		 update Student 
		 set advisor_id=@advisorID
		 where student_id=@studentID

Go
	
	Create procedure Procedures_AdminAddExam
		@Type varchar (40), 
		@date datetime, 
		@courseID int 
		As

		insert into Makeup_exam(date, type, course_id)
		values(@date, @type, @courseID)

Go
	Create procedure Procedures_AdminIssueInstallment 
		@Payment_ID int 
		AS

		Declare @amount int
		declare @n_installments int 
		declare @sdate datetime
		declare @edate datetime
		declare @i int 

		set @i=0
		
		
		select @n_installments=datediff(month, p.start_date, p.deadline)
		from Payment p
		where p.payment_id=@Payment_ID

		update Payment 
		set n_installments=@n_installments
		where payment_id=@Payment_ID

		select @amount=amount/ @n_installments,@sdate=start_date
		from Payment
		where payment_id=@Payment_ID

		set @edate=dateadd(MONTH,1,@sdate)

		
		while (@i<@n_installments)
		begin

		insert into Installment(payment_id,deadline,amount,start_date)
		values (@payment_id,@edate,@amount,@sdate)
		set @sdate=@edate
		set @edate=dateadd(MONTH,1,@sdate)
		set @i=@i+1

		end
		
		

Go
	Create procedure Procedures_AdminDeleteCourse
		@Course_ID int
		AS 

		delete from slot 
		where course_id=@course_id

		delete from Student_Instructor_Course_Take
		where course_id=@Course_ID

		delete from Course_Semester
		where course_id=@Course_ID

		delete from GradPlan_Course
		where course_id=@Course_ID

		delete from Request
		where course_id=@Course_ID

		delete from Instructor_Course
		where course_id=@Course_ID

		delete from Exam_Student
		where course_id=@Course_ID

		delete from MakeUp_Exam
		where course_id=@Course_ID

		delete from PreqCourse_course
		where course_id=@Course_ID
		
		delete from PreqCourse_course
		where prerequisite_course_id=@Course_ID

		delete from Course
		where course_id=@course_id

	

		
Go
	create procedure Procedure_AdminUpdateStudentStatus
		@Student_ID int
		AS

		Declare @deadline datetime
		declare @status varchar(40)
		select @deadline=Installment.deadline, @status=Installment.status
		from Installment
		inner join Payment on Payment.payment_id=Installment.payment_id
		where Payment.student_id=@Student_ID
		
		if (current_timestamp > @deadline) AND (@status = 'NotPaid') 
			Update Student
			set financial_status =  0
			where student_id=@Student_ID
		else 
			Update Student
			set financial_status =  1
			where student_id=@Student_ID
Go		

	create function update_status(@Student_ID int)
		returns bit
		AS
		begin
		Declare @return_value bit
		Declare @deadline datetime
		declare @status varchar(40)
		select @deadline=Installment.deadline, @status=Installment.status
		from Installment
		inner join Payment on Payment.payment_id=Installment.payment_id
		where Payment.student_id=@Student_ID
		if (current_timestamp > @deadline) AND (@status = 'NotPaid')
			
			set @return_value =  0
		else 
			
			set @return_value =  1
		return @return_value
		End
		

Go

	create view all_Pending_Requests
		AS
		Select r.* , S.f_name+ ' ' + S.l_name AS Student_Name , A.name
		from Request r
		inner join Student S on S.Student_id= r.student_id
		inner join Advisor A on A.advisor_id = r.advisor_id
		where r.status = 'pending'
Go

	create procedure Procedures_AdminDeleteSlots
		@current_semester varchar (40)
		as

		declare @course_id int

		update slot 
		set course_id = null, instructor_id=null
		where course_id in (
			select Course_Semester.course_id 
			from Course_Semester
			inner join Course c on c.course_id = Course_Semester.course_id
			where not exists (
				select *
				from Course_Semester
				where Course_Semester.semester_code=@current_semester and c.course_id=Course_Semester.course_id
				)
			) 

Go
	Create function FN_AdvisorLogin (@ID int, @password varchar (40) )returns bit 
		AS
		begin 

		declare @return_value bit 
		declare @Real_password varchar(40)

		select @Real_password=password
		from Advisor
		where @ID=advisor_id

		if @Real_password=@password 
		set @return_value=1

		else set @return_value=0

		return @return_value 
		end

Go		
	create procedure Procedures_AdvisorCreateGP
		@Semester_code varchar (40), 
		@expected_graduation_date date, 
		@sem_credit_hours int, 
		@advisor_id int, 
		@student_id int
		AS
		declare @acquired_hours int

		select @acquired_hours=acquired_hours
		from Student
		where Student_id=@student_id

		if (@acquired_hours>157)
		insert into Graduation_Plan (semester_code, expected_grad_date,
			semester_credit_hours, advisor_id, student_id)
		Values(@Semester_code, @expected_graduation_date, @sem_credit_hours,
		@advisor_id, @student_id)


Go
	create procedure Procedures_AdvisorAddCourseGP
		@student_id int, 
		@Semester_code varchar (40), 
		@course_name varchar (40)
		
		As

		declare @course_id int
		declare @P_id int
	    

		select @course_id= C.course_id
		from Course C
		where c.name= @course_name
		
		select @P_id=plan_id
		from Graduation_Plan  
		where student_id=@student_id and semester_code=@Semester_code

		insert into GradPlan_Course(plan_id, semester_code, course_id)
		values(@P_id, @Semester_code,@course_id)
		
Go
	create procedure Procedures_AdvisorUpdateGP
		@expected_grad_date date ,
		@studentID int
		AS

		update Graduation_Plan
		set expected_grad_date =@expected_grad_date
		where student_id=@studentID

Go

	create procedure Procedures_AdvisorDeleteFromGP
		@studentID int, 
		@semester_code varchar (40),
		@course_id int 
		AS

		declare @plan_id int 

		select @plan_id=plan_id
		from Graduation_Plan
		where student_id=@studentID and semester_code=@semester_code

		delete from GradPlan_Course
		where plan_id=@plan_id and semester_code=@semester_code and course_id=@course_id

Go

	Create function FN_Advisors_Requests (@advisorID int) returns table
		AS
		return (
		select *
		from Request R
		where R.advisor_id=@advisorID)

Go

	create procedure Procedures_AdvisorApproveRejectCHRequest
		 @RequestID int, 
		 @Current_semester_code varchar (40)
		 AS
		 
		 declare @total_hours int
		 declare @requested_hours int
		 declare @student_id int 
		 declare @type varchar(40)
		 declare @amount int 
		 declare @i int =0
		 declare @paymentID int
		 declare @minDate date


		 select @student_id=student_id, @requested_hours=credit_hours,@type=type
		 from Request
		 where request_id=@RequestID

		 if (@type='credit_hours')
		 begin
		 select @total_hours=assigned_hours
		 from student 
		 where Student_id=@student_id

		 if 
		 @total_hours>=34 or @requested_hours>3
		 begin
		 update Request
		 set status='Rejected'
		 where request_id=@RequestID
		 end

		 if @total_hours<34 and @requested_hours<=3
		 begin
		 update Request
		 set status='Accepted'
		 where request_id=@RequestID

		 select @paymentID=Payment.payment_id
		 from Payment
		 where CURRENT_TIMESTAMP between start_date and deadline

		 select @minDate= min(start_date)
		 from Installment
		 where CURRENT_TIMESTAMP < start_date and payment_id=@paymentID


		 update Installment
		 set amount=amount+(@requested_hours*1000)
		 where start_date=@minDate		

		 select @amount=sum(I.amount)
		 from Installment I 
		 where payment_id=@paymentID

		 update Payment
		 set amount=@amount
		 where payment_id=@paymentID

		 end
		 end

		 

		
Go

	Create procedure Procedures_AdvisorViewAssignedStudents
		@AdvisorID int, 
		@major varchar (40)
		AS

		select S.Student_id, S.f_name + ' ' + S.l_name AS Student_Name, S.major, SCT.Course_name
		from Student S
		left outer join Students_Courses_transcript SCT on SCT.Student_id=S.Student_id
		where @AdvisorID=s.advisor_id and @major=S.major


Go
	Create procedure Procedures_AdvisorApproveRejectCourseRequest
		@RequestID int, 
		@current_semester_code varchar(40)
		AS

		Declare @taken bit 
		Declare @prereq int 
		Declare @CourseID int
		Declare @total_hours int
		Declare @Course_hours int
		Declare @status bit
		Declare @type varchar(40)
		Declare @studentID int
		Declare @instructorID int
		Declare @takenCourse int

		select @studentID=student_id
		from Request
		where request_id=@RequestID

		select @type=type
		from Request R
		where R.request_id=@RequestID

		if (@type='course')
		begin
		select @CourseID=R.course_id
		from Request R
		where R.request_id=@RequestID 

		if (
		select P.prerequisite_course_id
		from PreqCourse_course P 
		where P.course_id=@CourseID
			except(
				select SIC2.course_id
					from Student_Instructor_Course_Take SIC2
					where SIC2.student_id=@studentID) ) is null 
		begin
		
		set @taken='true'
		end
		else set @taken='false'

		select @Course_hours=credit_hours
		from Course
		where course_id=@CourseID

		select @total_hours=assigned_hours
		from student 
		where Student_id=@studentID

		if @total_hours>=34 or @Course_hours>3
		set @status='False'

		if @total_hours<34 and @Course_hours<=3
		set @status='True'

		if @taken='True' and @status='True' 
		begin
		update Request 
		set Status='Accepted'
		where request_id=@RequestID 
		end	
		
		else 
		update Request 
		set Status='Rejected'
		where request_id=@RequestID  
			

	    if @taken='True' and @status='True' 
		select @instructorID=IC.instructor_id
		from Instructor_Course IC
		where @CourseID=IC.course_id

		
		select @takenCourse=count(*)
		from Student_Instructor_Course_Take SICT
		where SICT.course_id=@CourseID and SICT.student_id=@studentID 

		if @takenCourse = 0 and @studentID is not null and @CourseID is not null and @instructorID is not null and @current_semester_code is not null
		begin

        insert into Student_Instructor_Course_Take (student_ID,course_id,instructor_id,semester_code)
	    values (@studentID,@CourseID,@instructorID,@current_semester_code)
		end

		end

Go 

	Create procedure Procedures_AdvisorViewPendingRequests
		@Advisor_ID int
		AS

		select R.*
		from Request R
		inner join Advisor A on A.advisor_id=R.advisor_id
		inner join Student S on S.Student_id=R.student_id
		where A.advisor_id=@Advisor_ID and r.status= 'pending'

Go
	Create function FN_StudentLogin  (@Student_ID int, @password varchar (40) )returns bit 
		AS
		begin 

		declare @return_value bit 
		declare @Real_password varchar(40)

		select @Real_password=password
		from Student
		where @Student_ID=Student_id

		if @Real_password=@password 
		set @return_value=1

		else set @return_value=0

		return @return_value 
		end
Go

	Create procedure Procedures_StudentaddMobile 
		@StudentID int, 
		@mobile_number varchar (40)
		AS

		Insert into Student_Phone(Student_id, Phone_number)
		Values(@StudentID, @mobile_number)

Go
	Create function FN_SemsterAvailableCourses(@semster_code varchar (40)) returns table
		AS
		return(
			select C.name
			from Course_Semester S
			inner join Course C on C.course_id=S.course_id
			where S.semester_code=@semster_code )
Go

	Create procedure Procedures_StudentSendingCourseRequest
		@Student_ID int, 
		@course_ID int, 
		@type varchar (40), 
		@comment varchar (40)
		AS

		insert into Request(student_id, course_id, type, comment)
		Values(@Student_ID, @course_ID, @type, @comment)

Go
	Create procedure Procedures_StudentSendingCHRequest
		 @StudentID int,
		 @credit_hours int,
		 @type varchar (40), 
		 @comment varchar (40)
		 As

		 insert into Request(student_id, credit_hours, type, comment)
		 values(@StudentID, @credit_hours, @type, @comment)

Go
	Create function FN_StudentViewGP (@student_ID int) returns table
		As 
		return(
			select S.student_id, S.f_name + ' ' + S.l_name As Student_name, 
			GP.plan_id, C.course_id, C.name, GP.semester_code, GP.expected_grad_date,
			GP.semester_credit_hours, GP.advisor_id
			from GradPlan_Course GPC
			inner join Graduation_Plan GP on GP.plan_id=GPC.plan_id
			inner join Student S on S.Student_id=GP.student_id
			inner join Course C on C.course_id=GPC.course_id
			where S.Student_id=@student_ID
		)

Go

	Create function FN_StudentUpcoming_installment(@StudentID int) returns date
		AS
		begin 
		Declare @return_value date 
		
		
		select @return_value=MIN(I.deadline)
		from Installment I
		inner join Payment P on P.payment_id=I.payment_id
		where P.student_id=@StudentID and I.status='NotPaid'

		Return @return_value
		end


Go
	create function FN_StudentViewSlot(@CourseID int, @InstructorID int) returns table
		As
		return (
			select S.slot_id, S.location, S.time, S.day
			from Instructor_Course IC
			inner join slot S on S.course_id=IC.course_id
			where IC.course_id=@CourseID and IC.instructor_id=@InstructorID)

Go


	Create procedure Procedures_StudentRegisterFirstMakeup
	/* we changed (E.date > @St_date) to (E.date < @St_date) to match data in uploaded insertions so it can output something*/
		@StudentID int, 
		@courseID int, 
		@studentCurrent_semester varchar (40)
		As

		Declare @St_date date
		Declare @end_date date 
		Declare @exam_id int
		Declare @grade varchar(40)

		select @St_date=s.start_date, @end_date=s.end_date
		from Semester s
		where s.semester_code=@studentCurrent_semester

		select @exam_id=E.exam_id
		from MakeUp_Exam E
		where E.course_id=@courseID and (E.date < @end_date) and (E.date < @St_date)
			and E.type='first makeup'

		select @grade=S.grade
		from Student_Instructor_Course_Take S
		where S.course_id=@CourseID and S.student_id=@StudentID 
		and (S.exam_type='Normal')

		if ((@grade ='F' or @grade ='FF' or @grade is null) and @exam_id is not null and @StudentID is not null and @courseID is not null)
		insert into Exam_Student
		values(@exam_id, @StudentID, @courseID)
Go
	
	Create Function FN_StudentCheckSMEligiability(@CourseID int, @StudentID int) returns bit 
		AS
		begin
		
		Declare @return_value bit 
		Declare @grade varchar(40)
		Declare @Scount int
		Declare @Wcount int

		select @grade=S.grade
		from Student_Instructor_Course_Take S
		where S.course_id=@CourseID and S.student_id=@StudentID 
		and (S.exam_type='First_makeup')

		select @Scount=count(*)
		from Student_Instructor_Course_Take S 
		where S.student_id=@StudentID and (S.grade='F' or S.grade='FF') and
		(S.semester_code like '%S%' and S.semester_code not like '%R%') or S.semester_code like '%R2%'

		select @Wcount=count(*)
		from Student_Instructor_Course_Take S 
		where S.student_id=@StudentID and (S.grade='F' or S.grade='FF') and
		S.semester_code like '%W%' and S.semester_code like '%R1%'

		if (@grade='F' or @grade='FF'or @grade ='FA') and (@Scount<=2 or @Wcount<=2)   
		set @return_value=1
		else set @return_value=0

		return @return_value 
		end

Go 

	Create Function extra_required(@CourseID int, @StudentID int) returns bit 
		AS
		begin
		
		Declare @return_value bit 
		Declare @grade varchar(40)
		Declare @Scount int
		Declare @Wcount int

		select @grade=S.grade
		from Student_Instructor_Course_Take S
		where S.course_id=@CourseID and S.student_id=@StudentID 
		and (S.exam_type='First_makeup')

		select @Scount=count(*)
		from Student_Instructor_Course_Take S 
		where S.student_id=@StudentID and (S.grade='F' or S.grade='FF') and
		(S.semester_code like '%S%' and S.semester_code not like '%R%') or S.semester_code like '%R2%'

		select @Wcount=count(*)
		from Student_Instructor_Course_Take S 
		where S.student_id=@StudentID and (S.grade='F' or S.grade='FF') and
		S.semester_code like '%W%' and S.semester_code like '%R1%'

		if (@grade='F' or @grade='FF'or @grade ='FA') and (@Scount>2 or @Wcount>2)   
		set @return_value=1
		else set @return_value=0


		return @return_value
		end

Go

	Create procedure Procedures_StudentRegisterSecondMakeup
	/* we changed (E.date < @end_date) to (E.date > @end_date) again to match uploaded insertions and see output */
		@StudentID int, 
		@courseID int, 
		@Student_Current_Semester Varchar (40)
		AS

		Declare @eligible bit
		Declare @St_date date
		Declare @end_date date 
		Declare @exam_id int

		select @St_date=s.start_date, @end_date=s.end_date
		from Semester s
		where s.semester_code=@student_Current_semester

		select @exam_id=E.exam_id
		from MakeUp_Exam E
		where @courseID=E.course_id and (E.date > @end_date) and (E.date > @St_date)
			and E.type='second makeup'


		set @eligible=dbo.FN_StudentCheckSMEligiability(@courseID, @StudentID)
		
		if @eligible=1
		insert into Exam_Student
		values(@exam_id, @StudentID, @courseID)

Go

		Create procedure Procedures_ViewRequiredCourses
		@StudentID int, 
		@Current_semester_code Varchar (40)
		As
		Declare @eligible bit

		Select C.*
		from Course C full outer join Student_Instructor_Course_Take SICT on  SICT.course_id=C.course_id
		where (dbo.extra_required(C.course_id, @StudentID)=1) and @Current_semester_code=SICT.semester_code
			
Go

	Create procedure Procedures_ViewOptionalCourse
		@StudentID int, 
		@Current_semester_code Varchar (40)
		AS

		declare @courseID int
		declare @major varchar(40)

		select @major=major
		from Student
		where Student_id=@StudentID

		select C.course_id
		from Course C 
		where C.major=@major and (
		select P.prerequisite_course_id
		from PreqCourse_course P 
		where P.course_id in (select SIC3.course_id
							 from Student_Instructor_Course_Take SIC3
							 where SIC3.student_id=@StudentID and SIC3.semester_code=@Current_semester_code)
			except(
				select SIC2.course_id
					from Student_Instructor_Course_Take SIC2
					where SIC2.student_id=@studentID) ) is null 

		except(
		select SIC.course_id
		from Student_Instructor_Course_Take SIC
		where SIC.student_id=@StudentID and (SIC.grade !='FA' or SIC.grade!='F' or SIC.grade!='FF' ) )

Go
		
	Create procedure Procedures_ViewMS
		@StudentID int
		AS
		declare @major varchar (40)

		select @major= s.faculty
		from Student s
		where s.Student_id= @StudentID

		select course_id
		from Course
		where course.major=@major
		except(
		select course_id
		from Student_Instructor_Course_Take
		where student_id=@StudentID and (grade!='f' or grade!='ff' or grade!='fa')
		)



Go
		Create procedure Procedures_ChooseInstructor
		@Student_ID int, 
		@Instructor_ID int, 
		@Course_ID int,
		@current_semester_code varchar(40)
		AS


		update Student_Instructor_Course_Take 
		set instructor_id=@Instructor_ID
		where student_id=@Student_ID and course_id=@Course_ID and semester_code=@current_semester_code
		
Go 
	
	-- Adding 10 records to the Course table
INSERT INTO Course(name, major, is_offered, credit_hours, semester)  VALUES
( 'Mathematics 2', 'Science', 1, 3, 2),
( 'CSEN 2', 'Engineering', 1, 4, 2),
( 'Database 1', 'MET', 1, 3, 5),
( 'Physics', 'Science', 0, 4, 1),
( 'CSEN 4', 'Engineering', 1, 3, 4),
( 'Chemistry', 'Engineering', 1, 4, 1),
( 'CSEN 3', 'Engineering', 1, 3, 3),
( 'Computer Architecture', 'MET', 0, 3, 6),
( 'Computer Organization', 'Engineering', 1, 4, 4),
( 'Database2', 'MET', 1, 3, 6);


-- Adding 10 records to the Instructor table
INSERT INTO Instructor(name, email, faculty, office) VALUES
( 'Professor Smith', 'prof.smith@example.com', 'MET', 'Office A'),
( 'Professor Johnson', 'prof.johnson@example.com', 'MET', 'Office B'),
( 'Professor Brown', 'prof.brown@example.com', 'MET', 'Office C'),
( 'Professor White', 'prof.white@example.com', 'MET', 'Office D'),
( 'Professor Taylor', 'prof.taylor@example.com', 'Mechatronics', 'Office E'),
( 'Professor Black', 'prof.black@example.com', 'Mechatronics', 'Office F'),
( 'Professor Lee', 'prof.lee@example.com', 'Mechatronics', 'Office G'),
( 'Professor Miller', 'prof.miller@example.com', 'Mechatronics', 'Office H'),
( 'Professor Davis', 'prof.davis@example.com', 'IET', 'Office I'),
( 'Professor Moore', 'prof.moore@example.com', 'IET', 'Office J');

-- Adding 10 records to the Semester table
INSERT INTO Semester(semester_code, start_date, end_date) VALUES
('W23', '2023-10-01', '2024-01-31'),
('S23', '2023-03-01', '2023-06-30'),
('S23R1', '2023-07-01', '2023-07-31'),
('S23R2', '2023-08-01', '2023-08-31'),
('W24', '2024-10-01', '2025-01-31'),
('S24', '2024-03-01', '2024-06-30'),
('S24R1', '2024-07-01', '2024-07-31'),
('S24R2', '2024-08-01', '2024-08-31')

-- Adding 10 records to the Advisor table
INSERT INTO Advisor(name, email, office, password) VALUES
( 'Dr. Anderson', 'anderson@example.com', 'Office A', 'password1'),
( 'Prof. Baker', 'baker@example.com', 'Office B', 'password2'),
( 'Dr. Carter', 'carter@example.com', 'Office C', 'password3'),
( 'Prof. Davis', 'davis@example.com', 'Office D', 'password4'),
( 'Dr. Evans', 'evans@example.com', 'Office E', 'password5'),
( 'Prof. Foster', 'foster@example.com', 'Office F', 'password6'),
( 'Dr. Green', 'green@example.com', 'Office G', 'password7'),
( 'Prof. Harris', 'harris@example.com', 'Office H', 'password8'),
( 'Dr. Irving', 'irving@example.com', 'Office I', 'password9'),
( 'Prof. Johnson', 'johnson@example.com', 'Office J', 'password10');

-- Adding 10 records to the Student table
INSERT INTO Student (f_name, l_name, GPA, faculty, email, major, password, financial_status, semester, acquired_hours, assigned_hours, advisor_id)   VALUES 
( 'John', 'Doe', 3.5, 'Engineering', 'john.doe@example.com', 'CS', 'password123', 1, 1, 90, 30, 1),
( 'Jane', 'Smith', 3.8, 'Engineering', 'jane.smith@example.com', 'CS', 'password456', 1, 2, 85, 34, 2),
( 'Mike', 'Johnson', 3.2, 'Engineering', 'mike.johnson@example.com', 'CS', 'password789', 1, 3, 75, 34, 3),
( 'Emily', 'White', 3.9, 'Engineering', 'emily.white@example.com', 'CS', 'passwordabc', 0, 4, 95, 34, 4),
( 'David', 'Lee', 3.4, 'Engineering', 'david.lee@example.com', 'IET', 'passworddef', 1, 5, 80, 34, 5),
( 'Grace', 'Brown', 3.7, 'Engineering', 'grace.brown@example.com', 'IET', 'passwordghi', 0, 6, 88, 34, 6),
( 'Robert', 'Miller', 3.1, 'Engineerings', 'robert.miller@example.com', 'IET', 'passwordjkl', 1, 7, 78, 34, 7),
( 'Sophie', 'Clark', 3.6, 'Engineering', 'sophie.clark@example.com', 'Mechatronics', 'passwordmno', 1, 8, 92, 34, 8),
( 'Daniel', 'Wilson', 3.3, 'Engineering', 'daniel.wilson@example.com', 'DMET', 'passwordpqr', 1, 9, 87, 34, 9),
( 'Olivia', 'Anderson', 3.7, 'Engineeringe', 'olivia.anderson@example.com', 'Mechatronics', 'passwordstu', 0, 10, 89, 34, 10);


-- Adding 10 records to the Student_Phone table
INSERT INTO Student_Phone(student_id, phone_number) VALUES
(4, '456-789-0123'),
(5, '567-890-1234'),
(6, '678-901-2345'),
(7, '789-012-3456'),
(8, '890-123-4567'),
(9, '901-234-5678'),
(10, '012-345-6789');


-- Adding 10 records to the PreqCourse_course table
INSERT INTO PreqCourse_course(prerequisite_course_id, course_id) VALUES
(2, 7),
(3, 10),
(2, 4),
(5, 6),
(4, 7),
(6, 8),
(7, 9),
(9, 10),
(9, 1),
(10, 3);


-- Adding 10 records to the Instructor_Course table
INSERT INTO Instructor_Course (instructor_id, course_id) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10);


-- Adding 10 records to the Student_Instructor_Course_Take table
INSERT INTO Student_Instructor_Course_Take (student_id, course_id, instructor_id, semester_code,exam_type, grade) VALUES
(1, 1, 1, 'W23', 'Normal', 'A'),
(2, 2, 2, 'S23', 'First_makeup', 'B'),
(3, 3, 3, 'S23R1', 'Second_makeup', 'C'),
(4, 4, 4, 'S23R2', 'Normal', 'B+'),
(5, 5, 5, 'W23', 'Normal', 'A-'),
(6, 6, 6, 'W24', 'First_makeup', 'B'),
(7, 7, 7, 'S24', 'Second_makeup', 'C+'),
(8, 8, 8, 'S24R1', 'Normal', 'A+'),
(9, 9, 9, 'S24R2', 'Normal', 'FF'),
(10, 10, 10, 'S24', 'First_makeup', 'B-');



-- Adding 10 records to the Course_Semester table
INSERT INTO Course_Semester (course_id, semester_code) VALUES
(1, 'W23'),
(2, 'S23'),
(3, 'S23R1'),
(4, 'S23R2'),
(5, 'W23'),
(6, 'W24'),
(7, 'S24'),
(8, 'S24R1'),
(9, 'S24R2'),
(10, 'S24');

-- Adding 10 records to the Slot table
INSERT INTO Slot (day, time, location, course_id, instructor_id) VALUES
( 'Monday', 'First', 'Room A', 1, 1),
( 'Tuesday', 'First', 'Room B', 2, 2),
( 'Wednesday', 'Third', 'Room C', 3, 3),
( 'Thursday', 'Fifth', 'Room D', 4, 4),
( 'Saturday', 'Second', 'Room E', 5, 5),
( 'Monday', 'Fourth', 'Room F', 6, 6),
( 'Tuesday', 'Second', 'Room G', 7, 7),
( 'Wednesday', 'Fifth', 'Room H', 8, 8),
( 'Thursday', 'First', 'Room I', 9, 9),
( 'Sunday', 'Fourth', 'Room J', 10, 10);


-- Adding 10 records to the Graduation_Plan table
INSERT INTO Graduation_Plan (semester_code, semester_credit_hours, expected_grad_date, student_id, advisor_id) VALUES
( 'W23', 90,    '2024-01-31' ,   1, 1),
( 'S23', 85,    '2025-01-31'  ,     2, 2),
( 'S23R1', 75,  '2025-06-30' ,  3, 3),
( 'S23R2', 95,  '2024-06-30' , 4, 4),
( 'W23', 80,    '2026-01-31'   ,  5, 5),
( 'W24', 88,    '2024-06-30'   ,    6, 6),
( 'S24', 78,    '2024-06-30'    ,  7, 7),
( 'S24R1', 92,  '2025-01-31'  , 8, 8),
( 'S24R2', 87,  '2024-06-30'    ,  9, 9),
( 'S24', 89,    '2025-01-31'    ,    10, 10);

-- Adding 10 records to the GradPlan_Course table
INSERT INTO GradPlan_Course(plan_id, semester_code, course_id) VALUES
(1, 'W23', 1),
(2, 'S23', 2),
(3, 'S23R1', 3),
(4, 'S23R2', 4),
(5, 'W23', 5),
(6, 'W24', 6),
(7, 'S24', 7),
(8, 'S24R1', 8),
(9, 'S24R2', 9),
(10, 'S24', 10);

-- Adding 10 records to the Request table
INSERT INTO Request (type, comment, status, credit_hours, course_id, student_id, advisor_id) VALUES 
( 'course', 'Add courses', 'pending', null, 1, 1, 2),
( 'course', 'Need to change course', 'approved', null, 2, 2, 2),
( 'credit_hours', 'Add credit hours', 'pending', 3, null, 3, 3),
( 'credit_hours', 'Request for reduced credit hours', 'approved', 1, null, 4, 5),
( 'course', 'Request for special course', 'rejected', null, 5, 5, 5),
( 'credit_hours', 'Request for extra credit hours', 'pending', 4, null, 6, 7),
( 'course', 'Request for course withdrawal', 'approved', null, 7, 7, 7),
( 'course', 'Request for course addition', 'rejected', null, 8, 8, 8),
( 'credit_hours', 'Request for reduced credit hours', 'approved', 2, null, 9, 8),
( 'course', 'Request for course substitution', 'pending', null, 10, 10, 10);

-- Adding 10 records to the MakeUp_Exam table
INSERT INTO MakeUp_Exam (date, type, course_id) VALUES
('2023-02-10', 'First MakeUp', 1),
('2023-02-15', 'First MakeUp', 2),
('2023-02-05', 'First MakeUp', 3),
('2023-02-25', 'First MakeUp', 4),
('2023-02-05', 'First MakeUp', 5),
('2024-09-10', 'Second MakeUp', 6),
('2024-09-20', 'Second MakeUp', 7),
('2024-09-05', 'Second MakeUp', 8),
('2024-09-10', 'Second MakeUp', 9),
( '2024-09-15', 'Second MakeUp', 10);

-- Adding 10 records to the Exam_Student table
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (1, 1, 1);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (1, 2, 2);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (1, 3, 3);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (2, 2, 4);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (2, 3, 5);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (2, 4, 6);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (3, 3, 7);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (3, 4, 8);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (3, 5, 9);
INSERT INTO Exam_Student(exam_id, student_id,course_id) VALUES (4, 4, 10);

-- Adding 10 records to the Payment table
INSERT INTO Payment (amount, start_date,n_installments, status, fund_percentage, student_id, semester_code, deadline)  VALUES
( 500, '2023-11-22', 1, 'notPaid', 50.00, 1, 'W23', '2023-12-22'),
( 700, '2023-11-23', 1, 'notPaid', 60.00, 2, 'S23', '2023-12-23'),
( 600, '2023-11-24', 4, 'notPaid', 40.00, 3, 'S23R1', '2024-03-24'),
( 800, '2023-11-25', 1, 'notPaid', 70.00, 4, 'S23R2', '2023-12-25'),
( 550, '2023-11-26', 5, 'notPaid', 45.00, 5, 'W23', '2024-04-26'),
( 900, '2023-11-27', 1, 'notPaid', 80.00, 6, 'W24', '2023-12-27'),
( 750, '2023-10-28', 2, 'Paid', 65.00, 7, 'S24', '2023-12-28'),
( 620, '2023-08-29', 4, 'Paid', 55.00, 8, 'S24R1', '2023-12-29'),
( 720, '2023-11-30', 2, 'notPaid', 75.00, 9, 'S24R2', '2024-01-30'),
( 580, '2023-11-30', 1, 'Paid', 47.00, 10, 'S24', '2023-12-31');



-- Adding 10 records to the Installment table
INSERT INTO Installment (payment_id, start_date, amount, status, deadline) VALUES
(1, '2023-11-22', 50, 'notPaid','2023-12-22'),
(2, '2023-11-23', 70, 'notPaid','2023-12-23'),
(3, '2023-12-24', 60, 'notPaid','2024-01-24'),
( 4,'2023-11-25', 80, 'notPaid','2023-12-25'),
(5, '2024-2-26', 55, 'notPaid','2024-3-26'),
( 6,'2023-11-27', 90, 'notPaid','2023-12-06'),
(7, '2023-10-28', 75, 'Paid','2023-11-28'),
( 7,'2023-11-28', 62, 'Paid','2023-12-28'),
( 9,'2023-12-30', 72, 'notPaid','2024-01-30'),
( 10,'2023-11-30', 58, 'Paid','2023-12-30');
	


declare @student_id int
execute Procedures_StudentRegistration 'Ahmed','Mohamed','11111111','BI','Samia.Ahmed@email.com','BI',2,@student_id output
print @student_id;

declare @advisor_id int 
execute Procedures_AdvisorRegistration 'Samia','s123456','samia@email.com','B1.202',@advisor_id output
print @advisor_id

execute Procedures_AdminListStudents

execute Procedures_AdminListAdvisors

execute AdminListStudentsWithAdvisors

execute AdminAddingSemester '2024-10-01','2024-01-31','W25'

execute Procedures_AdminAddingCourse'BI','2',3,'IntroductionToEverything',1

execute Procedures_AdminLinkInstructor 1,3,3

execute Procedures_AdminLinkStudent 1,2,3,'W25'

execute Procedures_AdminLinkStudentToAdvisor 11,11

execute Procedures_AdminAddExam 'First Makeup', '2024-12-02', 11

INSERT INTO Payment (amount, start_date, status, fund_percentage, student_id, semester_code, deadline)  VALUES
( 1000, '2023-02-22', 'notPaid', 50.00, 1, 'W23', '2023-12-22')

execute Procedures_AdminIssueInstallment 11

execute Procedures_AdminDeleteCourse 10

INSERT INTO Payment (amount, start_date, status, fund_percentage, student_id, semester_code, deadline)  VALUES
( 1000, '2022-02-22', 'notPaid', 50.00, 2, 'W23', '2022-04-22')

execute Procedures_AdminIssueInstallment 12

execute Procedure_AdminUpdateStudentStatus 2

execute Procedures_AdminDeleteSlots 'S24R2'

declare @success bit
set @success=dbo.FN_AdvisorLogin(11, 's123456')
print @success

update student 
set acquired_hours=158
where Student_id=11

execute Procedures_AdvisorCreateGP 'S24R2',  '2024-01-31',  90, 11, 11

execute Procedures_AdvisorAddCourseGP 11,'S24R2', 'IntroductionToEverything'

execute Procedures_AdvisorUpdateGP '2025-01-31', 11

execute Procedures_AdvisorDeleteFromGP 11,'S24R2', 11

select *
from dbo.FN_Advisors_Requests(7)

execute Procedures_AdvisorApproveRejectCHRequest 3, 'S24R2'
select * 
from Request


insert into student 
values ( 'Oliviaa', 'Andersonn', 3.7, 'Engineeringe', 'olivia.anderson@example.com', 'Mechatronics', 'passwordstu', 0, 10, 89, 30, 10);

insert into Payment (amount, start_date, status, fund_percentage, student_id, semester_code, deadline)  
VALUES (550, '2023-11-26', 'notPaid', 45.00, 12, 'W23', '2024-04-26');

insert into request (type, comment, status, credit_hours, course_id, student_id, advisor_id)
values ( 'credit_hours', 'Add credit hours', 'pending', 3, null, 12, 10);

execute Procedures_AdminIssueInstallment 13

execute Procedures_AdvisorApproveRejectCHRequest 12, 'S24R2'

execute Procedures_AdvisorViewAssignedStudents 10, 'Mechatronics'

insert into Student_Instructor_Course_Take (student_id, course_id, instructor_id, semester_code,exam_type, grade)
VALUES
(1, 9, 9, 'W23', 'Normal', 'A');

insert into Request (type, comment, status, credit_hours, course_id, student_id, advisor_id) 
VALUES ( 'course', 'Request for additional course', 'pending', 2, 8, 12, 10)

select *
from Student_Instructor_Course_Take


execute Procedures_AdvisorApproveRejectCourseRequest 14, 'S24R2'
 
execute Procedures_AdvisorViewPendingRequests 7

declare @value bit
set @value= dbo.FN_StudentLogin (1,'password123')
print @value

execute Procedures_StudentaddMobile 3, '452-709-0153'
select *
from Student_Phone

select *
from dbo.FN_SemsterAvailableCourses ('S24R2')

execute Procedures_StudentSendingCourseRequest 8, 7, 'course', 'Request for course addition'
select *
from Request

execute Procedures_StudentSendingCHRequest 8, 7, 'credit_hours', 'Request for course addition'

select*
from dbo.FN_StudentViewGP (2)

go
declare @value date
set @value= dbo.FN_StudentUpcoming_installment (12)
print @value
go

select *
from dbo.FN_StudentViewSlot (9,9)


insert into Student_Instructor_Course_Take (student_id, course_id, instructor_id, semester_code,exam_type, grade) VALUES
(6, 5, 6, 'W24', 'Normal', 'F')


execute Procedures_StudentRegisterFirstMakeup 6,5,'W24'


insert into Student_Instructor_Course_Take (student_id, course_id, instructor_id, semester_code,exam_type, grade) VALUES
(6, 8, 6, 'S24R1', 'First_makeup', 'F')

go
declare @value bit
set @value=dbo.FN_StudentCheckSMEligiability (7,7)
print @value
go

execute Procedures_StudentRegisterSecondMakeup 6,8,'S24R1'

insert into Course_Semester (course_id, semester_code) VALUES
(5,'S24R1'), (4,'S24R1')

insert into Student_Instructor_Course_Take (student_id, course_id, instructor_id, semester_code,exam_type, grade) VALUES
(6, 3, 6, 'S24R1', 'First_makeup', 'F')


insert into Student_Instructor_Course_Take (student_id, course_id, instructor_id, semester_code,exam_type, grade) VALUES
(6, 4, 6, 'S24R1', 'First_makeup', 'F')

insert into Student_Instructor_Course_Take (student_id, course_id, instructor_id, semester_code,exam_type, grade) VALUES
(6, 7, 6, 'S24', 'First_makeup', 'F')

execute Procedures_ViewRequiredCourses 6,'S24R'

execute Procedures_ViewOptionalCourse 6, 'W24'

execute Procedures_ViewMS 6 

execute Procedures_ChooseInstructor 2,3,2,'S23'

execute Procedures_ViewOptionalCourse 6, 'W24' 

execute clearAllTables

execute DropAllTables

